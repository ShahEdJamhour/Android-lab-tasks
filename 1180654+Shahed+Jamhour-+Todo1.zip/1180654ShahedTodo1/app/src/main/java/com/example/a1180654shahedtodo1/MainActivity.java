package com.example.a1180654shahedtodo1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button button1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ///////////////////////////////////////////////////////////////////
        /////////////////////   BUTTONS  /////////////////////////////////
        /////////////////////////////////////////////////////////////////
        Button button1 = (Button) findViewById(R.id.button1);
        Button button2 = (Button) findViewById(R.id.button2);
        Button button3 = (Button) findViewById(R.id.button3);
        Button button4 = (Button) findViewById(R.id.button4);
        Button button5 = (Button) findViewById(R.id.button5);
        Button button_SAY = (Button) findViewById(R.id.buttonsay);

        //////////////////////////////////////////////////////////////
        /////////    TextViews    ///////////////////////////////////
        ////////////////////////////////////////////////////////////

        TextView HeadTextView = (TextView) findViewById(R.id.HeadTextView);

        TextView BodyTextView = (TextView) findViewById(R.id.BodyTextView);
        TextView LegstextView = (TextView) findViewById(R.id.LegstextView);

        ///////////Switch/////////////////////////////
        Switch simpleSwitch = (Switch) findViewById(R.id.simpleSwitch);
        ///////////////////////////////////////////////////
        TextView output = (TextView) findViewById(R.id.Output);

        EditText editText = (EditText) findViewById(R.id.Input);
////////////////////////////////////////////////////////////////////////////

        button1.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (simpleSwitch.isChecked()) {
                    HeadTextView.setText("(o");
                    BodyTextView.setText("/|");


                }

            }

        }
        ));
//////////////////////////////////////////////////////////////////////////////

        button2.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (simpleSwitch.isChecked()) {
                    HeadTextView.setText("o");

                    BodyTextView.setText("<|\\");


                }

            }

        }
        ));

//////////////////////////////////////////////////////////////
        button3.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (simpleSwitch.isChecked()) {
                    HeadTextView.setText("o");

                    BodyTextView.setText("/|\\");


                }

            }

        }
        ));

////////////////////////////////////////////////////////////

        button4.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (simpleSwitch.isChecked()) {
                    HeadTextView.setText("o");

                    LegstextView.setText("/ >");


                }

            }

        }
        ));
/////////////////////////////////////////////////
        button5.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (simpleSwitch.isChecked()) {

                    LegstextView.setText("/ \\");


                }

            }

        }
        ));

///////////////////////////////////////////////////////////
        button_SAY.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (simpleSwitch.isChecked()) {

                    output.setText(editText.getText().toString());

                }

            }

        }
        ));










    }
}