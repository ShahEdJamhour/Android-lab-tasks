package com.example.lab1task1180654shahed;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button button7, button8;
    TextView textView7;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button7= findViewById(R.id.button7);
        button8= findViewById(R.id.button8);
        textView7= findViewById((R.id.textView7));

        button7.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String currentValue= textView7.getText().toString();
                int value=Integer.parseInt(currentValue);
                value++;
                textView7.setText(String.valueOf(value));

            }






        }
        ));



        button8.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String currentValue= textView7.getText().toString();
                int value=Integer.parseInt(currentValue);
                value--;
                textView7.setText(String.valueOf(value));

            }






        }
        ));























    }
}